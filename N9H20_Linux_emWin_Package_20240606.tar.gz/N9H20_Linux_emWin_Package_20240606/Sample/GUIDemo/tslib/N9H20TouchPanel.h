#ifndef __N9H20TOUCHPANEL_H__
#define __N9H20TOUCHPANEL_H__

#include <unistd.h>

void TouchTask(void);

#endif
